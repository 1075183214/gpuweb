---
name: WebGPU spec issue
about: 'Standardization/specification issue'
title: ''
labels: ''
assignees: ''

---


