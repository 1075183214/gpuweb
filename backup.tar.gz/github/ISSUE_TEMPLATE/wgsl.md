---
name: WebGPU Shading Language Issue.
about: 'WebGPU Shading Language Issues'
title: ''
labels: 'wgsl'
assignees: ''

---
