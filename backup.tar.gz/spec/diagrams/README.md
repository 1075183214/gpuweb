Source files for diagrams generated into `../img/`. Edit these files and run `make diagrams` to regenerate.
