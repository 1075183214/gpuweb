Files in this directory are used as images in the spec.

Note, `.mmd.svg` files are generated from sources in `../diagrams`. Edit the source files instead of the generated files.
