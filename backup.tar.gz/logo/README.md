# WebGPU Logo

<img alt="WebGPU logo" src="webgpu-responsive.svg" width="400">

This folder containts several variations of the WebGPU Logo for use in a variety of situations.
For additional details see [https://www.w3.org/2023/02/webgpu-logos.html](https://www.w3.org/2023/02/webgpu-logos.html)

## License

All variations of the WebGPU logo represented here are licensed under [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/).
See [https://www.w3.org/2023/02/webgpu-logos.html](https://www.w3.org/2023/02/webgpu-logos.html) for further details on usage.
